About MPQ Master
================
  I rewrote MPQ tool, now it is named MPQ Master.
  It is much faster and smaller than my old MPQ Workshop.

Language API
============
  The API Entrance is written in Object Pascal/Delphi. I put it
in folder LangAPI. Welcome to make language files for this tool.

Contact Me
==========
  Homepage: http://www.soarchin.com
  E-Mail: webmaster@soarchin.com
